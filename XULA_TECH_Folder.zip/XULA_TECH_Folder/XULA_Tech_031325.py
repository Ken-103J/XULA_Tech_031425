from Utils import load_data, call_R, generate_ad
import os

if __name__ == "__main__":

    dataset_path = "D:/Youtube_Folder/XULA_Tech/ad_click_dataset.csv"
    processed_data_path = "D:/Youtube_Folder/XULA_Tech/processed_data.csv"
    r_script_path = "D:/Youtube_Folder/XULA_Tech/process_data.r"
    
    api_key = os.getenv("OPENAI_API_KEY")  
    
    if not api_key:
        raise ValueError("API key is not set. Please set it as an environment variable.")
    
    if not os.path.exists(dataset_path):
        raise FileNotFoundError("Dataset file not found at: " + dataset_path)
    
    print("Loading the dataset from: " + dataset_path)
    dataset = load_data(dataset_path)
    print("Dataset loaded successfully.")
    
    print("Processing data using the R script...")
    call_R(r_script_path, dataset_path, processed_data_path)
    print("Data processing complete. Processed data saved to: " + processed_data_path)

    print("Generating an advertisement...")
    sample_prompt = "Generate an ad focused on a 21-year-old girl who likes technology, emphasizing the user-friendliness of the technology."
    ad_text = generate_ad(sample_prompt, api_key)
    print("Generated Advertisement:")
    print(ad_text)