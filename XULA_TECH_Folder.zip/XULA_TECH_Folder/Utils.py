import pandas as pd
import subprocess
import openai
import os

def load_data(file_path):
    """load dataset"""
    if not os.path.isfile(file_path):
        raise FileNotFoundError("The file does not exist: " + file_path)
    return pd.read_csv(file_path)

def call_R(R_script, input_data, output_file):
    """Execute  R"""
    try:
        command = ["Rscript", R_script, input_data, output_file]
        subprocess.run(command, check=True)
        print("R script executed successfully. Data saved to: " + output_file)
    except subprocess.CalledProcessError as e:
        raise RuntimeError("R script execution failed: " + str(e))

def generate_ad(prompt, api_key):
    """Generate an advertisement """
    openai.api_key = api_key
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an assistant to create ads."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=100,
            temperature=0.7
        )
        return response['choices'][0]['message']['content'].strip()
    except Exception as e:
        raise RuntimeError("Failed to generate ad: " + str(e))
